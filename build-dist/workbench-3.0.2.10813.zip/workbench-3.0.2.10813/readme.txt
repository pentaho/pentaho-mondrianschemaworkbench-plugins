# $Id: //open/mondrian/workbench/readme.txt#1 $
# This software is subject to the terms of the Common Public License
# Agreement, available at the following URL:
# http://www.opensource.org/licenses/cpl.html.
# Copyright (C) 2007 Cincom Inc, JasperSoft and others

Welcome to the Mondrian Schema Workbench.

The Mondrian Schema Workbench allows you to visually create and test Mondrian OLAP cube schemas.

See the docs directory for documentation on the Workbench and Mondrian.


Technical Prerequisites for the Workbench

* Java 1.5.
* JDBC driver for your database in the drivers directory.


Start the Workbench by running "workbench.bat" (Windows) or "workbench.sh" (for Unix/Linux) where you installed.



Sherman Wood
JasperSoft